from account import create_customer, create_account
from deposit import deposit
from withdrawn import withdraw
from transaction import transfer
from history import show_history
from balance import check_balance
from delete_account import delete_account
 

def main():
    while True:
        print("\n🏦 Welcome to Banking System")
        print("1. Create Customer")
        print("2. Create Account")
        print("3. Deposit")
        print("4. Withdraw")
        print("5. Transfer")
        print("6. Transaction History")
        print("7. Check Balance")
        print("8. Delete Account")
        print("9. Exit")

        choice = input("Enter your choice: ")

        if choice == "1":
            name = input("Enter customer name: ")
            email = input("Enter customer email: ")
            phone = input("Enter customer phone: ")
            dob = input("Enter customer DOB (YYYY-MM-DD): ")
            create_customer(name, email, phone, dob)

        elif choice == "2":
            cid = int(input("Enter customer ID: "))
            acc_type = input("Enter account type (savings/current): ")
            deposit_amt = float(input("Enter initial deposit: "))
            create_account(cid, acc_type, deposit_amt)

        elif choice == "3":
            acc = input("Enter account number: ")
            amt = float(input("Enter amount to deposit: "))
            deposit(acc, amt)

        elif choice == "4":
            acc = input("Enter account number: ")
            amt = float(input("Enter amount to withdraw: "))
            withdraw(acc, amt)

        elif choice == "5":
            sender = input("Enter sender account number: ")
            receiver = input("Enter receiver account number: ")
            amt = float(input("Enter amount to transfer: "))
            transfer(sender, receiver, amt)

        elif choice == "6":
            acc = input("Enter account number: ")
            show_history(acc)

        elif choice == "7":
            acc = input("Enter account number: ")
            check_balance(acc)

        elif choice == "8":
            acc = input("Enter account number: ")
            delete_account(acc)

        elif choice == "9":
            print("👋 Thank you for using the Banking System!")
            break

        else:
            print("❌ Invalid choice, try again.")
if __name__ == "__main__":          
    main()                           