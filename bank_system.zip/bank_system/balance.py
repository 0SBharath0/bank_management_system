from sqlconnect import get_connection

def check_balance(account_number):
    """Check balance of a given account"""
    conn = get_connection()
    if not conn:
        return
    
    cursor = conn.cursor()

    try:
        cursor.execute("SELECT balance FROM accounts WHERE account_number = %s", (account_number,))
        result = cursor.fetchone()

        if not result:
            print("❌ Account not found!")
            return

        balance = result[0]
        print(f"💰 Current Balance for Account {account_number}: {balance}")

    except Exception as e:
        print("❌ Error checking balance:", e)
    finally:
        conn.close()
