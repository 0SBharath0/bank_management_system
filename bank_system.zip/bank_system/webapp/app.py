import sys
import os

# add parent folder to Python path so sqlconnect.py can be imported
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from flask import Flask, render_template, request, redirect, url_for, flash
from sqlconnect import get_connection
# import backend functions
from account import create_customer, create_account
from deposit import deposit
from withdrawn import withdraw
from transaction import transfer
from history import show_history  # this should return a list of transactions

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'


@app.route('/')
def index():
    return render_template('index.html')


# ------------------ CREATE CUSTOMER PAGE ------------------
@app.route('/create_customer', methods=['GET', 'POST'])
def create_customer_page():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        phone = request.form['phone']
        dob = request.form['dob']   # ✅ collect DOB

        customer_id = create_customer(name, email, phone, dob)
        if customer_id:
            flash("✅ Customer created successfully!", "success")
        else:
            flash("❌ Customer must be at least 18 years old!", "danger")
        return redirect(url_for('index'))
    return render_template('create_customer.html')



# ------------------ CREATE ACCOUNT PAGE -------------------
@app.route('/create_account', methods=['GET', 'POST'])
def create_account_page():
    if request.method == 'POST':
        customer_id = request.form['customer_id']
        account_type = request.form['account_type']
        initial_deposit = request.form['initial_deposit']
        create_account(customer_id, account_type, initial_deposit)
        flash("✅ Account created successfully!", "success")
        return redirect(url_for('index'))
    return render_template('create_account.html')


# ------------------ DEPOSIT PAGE -------------------
@app.route('/deposit', methods=['GET', 'POST'])
def deposit_page():
    if request.method == 'POST':
        account_number = request.form['account_number']
        amount = request.form['amount']
        deposit(account_number, amount)
        flash("✅ Deposit completed!", "success")
        return redirect(url_for('index'))
    return render_template('deposit.html')


# ------------------ WITHDRAW PAGE -------------------
@app.route('/withdraw', methods=['GET', 'POST'])
def withdraw_page():
    if request.method == 'POST':
        account_number = request.form['account_number']
        amount = request.form['amount']

        from withdrawn import withdraw
        message, status = withdraw(account_number, amount)
        flash(message, status)

        return redirect(url_for('withdraw_page'))

    return render_template('withdraw.html')

# ------------------ TRANSFER PAGE -------------------
@app.route('/transfer', methods=['GET', 'POST'])
def transfer_page():
    if request.method == 'POST':
        sender = request.form['sender_account']
        receiver = request.form['receiver_account']
        amount = request.form['amount']
        transfer(sender, receiver, amount)
        flash("✅ Transfer completed!", "success")
        return redirect(url_for('index'))
    return render_template('transfer.html')


# ------------------ TRANSACTION HISTORY PAGE -------------------
# ------------------ TRANSACTION HISTORY PAGE -------------------
@app.route('/transaction_history', methods=['GET', 'POST'])
def transaction_history_page():
    account_number = request.args.get('account_number')  # from search box
    conn = get_connection()
    cursor = conn.cursor()

    if account_number:  # User searched for a specific account
        cursor.execute("""
            SELECT t.txn_id, a.account_number, t.txn_type, t.amount, t.txn_date
            FROM transactions t
            JOIN accounts a ON t.account_id = a.account_id
            WHERE a.account_number = %s
            ORDER BY t.txn_date DESC
            LIMIT 5
        """, (account_number,))
    else:  # Show all transactions
        cursor.execute("""
            SELECT t.txn_id, a.account_number, t.txn_type, t.amount, t.txn_date
            FROM transactions t
            JOIN accounts a ON t.account_id = a.account_id
            ORDER BY t.txn_date DESC
        """)

    transactions = cursor.fetchall()
    conn.close()

    return render_template('transaction_history.html',
                           transactions=transactions,
                           account_number=account_number)

# ------------------ CHECK BALANCE PAGE -------------------
@app.route('/check_balance', methods=['GET', 'POST'])
def check_balance_page():
    balance = None
    if request.method == 'POST':
        account_number = request.form['account_number']
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT balance FROM accounts WHERE account_number = %s", (account_number,))
        result = cursor.fetchone()
        conn.close()
        if result:
            balance = result[0]
            flash(f"💰 Current balance: {balance}", "success")
        else:
            flash("❌ Account not found!", "danger")
    return render_template('check_balance.html', balance=balance)

# ------------------ DELETE ACCOUNT PAGE -------------------
@app.route('/delete_account', methods=['GET', 'POST'])
def delete_account_page():
    if request.method == 'POST':
        account_number = request.form['account_number']

        from delete_account import delete_account  # don’t change backend
        result = delete_account(account_number)

        # Handle both old and new return styles
        if isinstance(result, tuple):
            message, status = result
        else:
            message, status = str(result), 'info'

        flash(message, status)
        return redirect(url_for('delete_account_page'))

    return render_template('delete_account.html')

if __name__ == '__main__':
    app.run(debug=True)
