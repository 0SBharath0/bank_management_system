from sqlconnect import get_connection
from decimal import Decimal

import mysql.connector
def deposit(account_number, amount):
    try:
        conn = get_connection()
        cursor = conn.cursor()

        # 1. Get account_id and old balance (using account_number)
        cursor.execute("SELECT account_id, balance FROM accounts WHERE account_number = %s", (account_number,))
        result = cursor.fetchone()
        if not result:
            print("❌ Account not found!")
            return

        account_id, old_balance = result
        new_balance = old_balance + Decimal(str(amount))


        # 2. Update balance
        cursor.execute("UPDATE accounts SET balance = %s WHERE account_number = %s",
                       (new_balance, account_number))

        # 3. Insert transaction (use account_id, not account_number)
        cursor.execute("INSERT INTO transactions (account_id, txn_type, amount) VALUES (%s, %s, %s)",
                       (account_id, "deposit", amount))

        conn.commit()
        print(f"✅ Deposit successful! New Balance: {new_balance}")

    except mysql.connector.Error as err:
        print(f"❌ Error in deposit: {err}")
    finally:
        cursor.close()
        conn.close()