from sqlconnect import get_connection
from decimal import Decimal

def transfer(sender_acc, receiver_acc, amount):
    """Transfer money between two accounts with minimum balance rule"""
    conn = get_connection()
    if not conn:
        return
    
    cursor = conn.cursor()

    try:
        # ✅ Ensure amount is Decimal
        amount = Decimal(str(amount))

        # Step 1: Check sender balance
        cursor.execute("SELECT account_id, balance FROM accounts WHERE account_number = %s", (sender_acc,))
        sender = cursor.fetchone()

        if not sender:
            print("❌ Sender account not found!")
            return
        sender_id, sender_balance = sender

        # Step 2: Check receiver account
        cursor.execute("SELECT account_id FROM accounts WHERE account_number = %s", (receiver_acc,))
        receiver = cursor.fetchone()

        if not receiver:
            print("❌ Receiver account not found!")
            return
        receiver_id = receiver[0]

        # Step 3: Minimum balance check
        if sender_balance - amount < Decimal("500"):
            print("❌ Transfer failed! Sender must maintain minimum balance of 500.")
            return

        # Step 4: Deduct from sender
        cursor.execute("UPDATE accounts SET balance = balance - %s WHERE account_number = %s", 
                       (amount, sender_acc))

        # Step 5: Add to receiver
        cursor.execute("UPDATE accounts SET balance = balance + %s WHERE account_number = %s", 
                       (amount, receiver_acc))

        # Step 6: Log transactions
        cursor.execute("INSERT INTO transactions (account_id, txn_type, amount) VALUES (%s, %s, %s)",
                       (sender_id, 'transfer_out', amount))
        cursor.execute("INSERT INTO transactions (account_id, txn_type, amount) VALUES (%s, %s, %s)",
                       (receiver_id, 'transfer_in', amount))

        # Step 7: Commit
        conn.commit()
        print(f"✅ Transfer of {amount:.2f} from {sender_acc} → {receiver_acc} successful!")

    except Exception as e:
        print("❌ Error in transfer:", e)
        conn.rollback()
    finally:
        conn.close()
