# history.py
from sqlconnect import get_connection

def show_history(account_number):
    """
    Show last 5 transactions for a given account number.
    """
    conn = get_connection()
    if not conn:
        print("❌ Could not connect to database.")
        return

    cursor = conn.cursor()

    try:
        # Find account_id from account_number
        cursor.execute("SELECT account_id FROM accounts WHERE account_number = %s", (account_number,))
        account = cursor.fetchone()

        if not account:
            print("❌ Account not found!")
            return

        account_id = account[0]

        # Fetch last 5 transactions
        cursor.execute("""
            SELECT txn_id, txn_type, amount, txn_date
            FROM transactions
            WHERE account_id = %s
            ORDER BY txn_date DESC
            LIMIT 5
        """, (account_id,))
        transactions = cursor.fetchall()

        if not transactions:
            print("ℹ️ No transactions found for this account.")
            return

        print(f"\n📜 Last 5 transactions for Account {account_number}:")
        print("-" * 60)
        for txn_id, txn_type, amount, txn_date in transactions:
            print(f"TxnID: {txn_id} | Type: {txn_type} | Amount: {amount} | Date: {txn_date}")

    except Exception as e:
        print("❌ Error fetching history:", e)
    finally:
        conn.close()
