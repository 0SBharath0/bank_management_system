from account import create_customer, create_account

# ✅ Test creating a customer
print("\n--- Creating Customer ---")
customer_id = create_customer(
    name="Alice Johnson",
    email="alice@example.com",
    phone="9876543210",
    dob="1995-06-15"   # YYYY-MM-DD format
)
print("Customer ID:", customer_id)

# ✅ Test creating an account for that customer
if customer_id:
    print("\n--- Creating Account ---")
    create_account(
        customer_id=customer_id,
        account_type="savings",   # or "current"
        initial_deposit=2000      # must be >= 1000
    )

# from account import create_customer, create_account

# # Step 1: Create a new customer
# cust_id = create_customer("Alice Smith", "alice@example.com", "9876543211", "1997-08-21")

# # Step 2: Create an account for that customer
# if cust_id:
#     create_account(cust_id, "Current", 2000)

# from deposit import deposit
# from account import create_account
# deposit('9577362319',1500)

# from withdrawn import withdraw

# # Case 1: Try to withdraw too much
# withdraw("2427142465", 3200)
# # ❌ Withdrawal failed! Minimum balance of 500 must be maintained.

# # Case 2: Valid withdrawal
# withdraw("2427142465", 1000)
# # ✅ Withdrawal of 1000 successful! Remaining balance: XXXX

# from transaction import transfer

# # Replace with your real account numbers
# sender_acc = "2427142465"      # sender's account
# receiver_acc = "9577362319"    # receiver's account
# amount = 500                  # amount to transfer

# # Run transfer
# transfer(sender_acc, receiver_acc, amount)

# from history import transaction_history

# transaction_history("2427142465", 5)
