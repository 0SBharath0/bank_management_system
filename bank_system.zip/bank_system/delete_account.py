# delete_account.py
from sqlconnect import get_connection

def delete_account(account_number):
    """Soft delete an account and return remaining balance to customer"""
    conn = get_connection()
    if not conn:
        return
    
    cursor = conn.cursor()

    try:
        # Step 1: Fetch account details
        cursor.execute("SELECT account_id, balance, is_active FROM accounts WHERE account_number = %s", (account_number,))
        result = cursor.fetchone()

        if not result:
            print("❌ Account not found!")
            return

        account_id, balance, is_active = result

        if not is_active:
            print("⚠️ Account already closed.")
            return

        # Step 2: Withdraw full balance (ignores minimum balance rule)
        if balance > 0:
            cursor.execute("UPDATE accounts SET balance = 0 WHERE account_number = %s", (account_number,))
            cursor.execute(
                "INSERT INTO transactions (account_id, txn_type, amount) VALUES (%s, %s, %s)",
                (account_id, 'account_closure', balance)
            )

        # Step 3: Soft delete (set inactive)
        cursor.execute("UPDATE accounts SET is_active = 0 WHERE account_number = %s", (account_number,))

        conn.commit()
        print(f"✅ Account {account_number} closed successfully. Returned balance: {balance}")

    except Exception as e:
        print("❌ Error deleting account:", e)
        conn.rollback()
    finally:
        conn.close()
