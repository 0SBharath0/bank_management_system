from sqlconnect import get_connection
from decimal import Decimal

def withdraw(account_number, amount):
    """Withdraw money from account with minimum balance rule.
       Returns (message, status) for Flask flash."""
    conn = get_connection()
    if not conn:
        return ("❌ Database connection failed!", "danger")

    cursor = conn.cursor()

    try:
        # Step 1: Get current balance
        cursor.execute("SELECT balance, account_id FROM accounts WHERE account_number = %s", (account_number,))
        result = cursor.fetchone()

        if not result:
            conn.close()
            return ("❌ Account not found!", "danger")

        current_balance, account_id = result

        # ✅ Ensure amount is Decimal
        amount = Decimal(str(amount))

        # Step 2: Check minimum balance rule
        if current_balance - amount < Decimal("500"):
            conn.close()
            return ("❌ Withdrawal failed! Minimum balance of 500 must be maintained.", "danger")

        # Step 3: Deduct balance
        cursor.execute("UPDATE accounts SET balance = balance - %s WHERE account_number = %s",
                       (amount, account_number))

        # Step 4: Log transaction
        cursor.execute("INSERT INTO transactions (account_id, txn_type, amount) VALUES (%s, %s, %s)",
                       (account_id, 'withdraw', amount))

        conn.commit()
        conn.close()

        return (f"✅ Withdrawal of {amount} successful! Remaining balance: {current_balance - amount:.2f}", "success")

    except Exception as e:
        conn.rollback()
        conn.close()
        return (f"❌ Error in withdrawal: {str(e)}", "danger")