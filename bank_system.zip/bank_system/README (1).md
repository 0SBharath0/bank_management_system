📄 README.md
# 🏦 Banking System (CLI + Web)

A **bank management system** built in Python with **two modes of operation**:
- **CLI mode**: A terminal-based application for backend operations.
- **Web mode**: A Flask-based web front-end for user-friendly interactions.

It supports **customer creation**, **account management**, **deposits/withdrawals**, **transfers**, **transaction history**, **balance checking**, and **account deletion**.

---

## ✨ Features
- Create customers and accounts  
- Deposit & withdraw funds  
- Transfer money between accounts  
- Enforce **minimum balance** rules  
- View transaction history (last 5 or all transactions)  
- Check account balance  
- Delete accounts safely  
- MIT Licensed (free to use)

---

## 🖥️ Project Structure


bank_system/
├── webapp/ (Flask Frontend)
│ ├── templates/ (HTML pages)
│ ├── app.py
│ ├── ...
├── main.py (CLI backend)
├── account.py
├── transaction.py
├── history.py
├── ...


---

## 🚀 Running the Project

### 1️⃣ CLI Mode (Terminal)
```bash
python main.py


You’ll see options like:

1. Create Customer
2. Create Account
3. Deposit
4. Withdraw
5. Transfer
6. Transaction History
7. Check Balance
8. Delete Account
9. Exit

2️⃣ Web Mode (Flask)
cd webapp
python app.py


Visit: http://127.0.0.1:5000 in your browser.

📸 Screenshots
🗂 Project Structure

🏠 Home Page

📜 Transaction History – All Transactions

📜 Transaction History – Single Account

⚙️ Technologies Used

Python 3

Flask (for frontend web app)

MySQL (database)

HTML / CSS (templates)

Bootstrap (styling)

🔮 Future Enhancements

Add user authentication / admin dashboard

Email or SMS alerts for transactions

Export statements as PDF/Excel

More robust validation & audit logs

Deploy on cloud hosting like Render / Railway / AWS

📜 License

This project is licensed under the MIT License
 — you’re free to use, modify, and distribute it.

👨‍💻 About

I developed this project as a self-learning project to strengthen Python, SQL, and Flask skills.
It started as a CLI app and later evolved into a web frontend.


---
![Project Structure](screenshots/project-structure.png)
![Home Page](screenshots/homepage.png)
![Transaction History All](screenshots/transaction-history-all.png)
![Transaction History Single](screenshots/transaction-history-single.png)
