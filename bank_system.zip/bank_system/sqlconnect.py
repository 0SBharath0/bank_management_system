import mysql.connector

# Function to connect to MySQL database
def get_connection():
    try:
        conn = mysql.connector.connect(
            host="localhost",
            user="root",         # your MySQL username
            password="abcd1234", # your MySQL password
            database="bank_system"
        )
        if conn.is_connected():
            print("✅ Connected to MySQL Database!")
        return conn
    except mysql.connector.Error as e:
        print("❌ Error while connecting to MySQL:", e)
        return None
