from sqlconnect import get_connection
import random
from datetime import datetime

def create_customer(name, email, phone, dob):
    """Create a new customer with DOB validation"""
    # ✅ Check age
    try:
        dob_date = datetime.strptime(dob, "%Y-%m-%d")  # adjust if your form sends different format
        age = (datetime.today() - dob_date).days // 365
        if age < 18:
            print("❌ Customer must be at least 18 years old!")
            return None
    except ValueError:
        print("❌ Invalid DOB format")
        return None

    conn = get_connection()
    if not conn:
        return
    cursor = conn.cursor()

    try:
        # Check if email or phone already exists
        cursor.execute(
            "SELECT customer_id FROM customers WHERE email = %s OR phone = %s",
            (email, phone))
        existing = cursor.fetchone()

        if existing:
            print(f"⚠️ Customer with this email/phone already exists! ID: {existing[0]}")
            return existing[0]  # reuse existing customer_id

        # Insert new customer
        query = "INSERT INTO customers (name, email, phone, dob) VALUES (%s, %s, %s, %s)"
        values = (name, email, phone, dob)
        cursor.execute(query, values)
        conn.commit()
        print("✅ Customer created successfully!")
        return cursor.lastrowid

    except Exception as e:
        print("❌ Error creating customer:", e)
    finally:
        conn.close()


def create_account(customer_id, account_type, initial_deposit):
    """Create a new account for a customer"""
    conn = get_connection()
    if not conn:
        return
    
    cursor = conn.cursor()
    try:
        account_number = str(random.randint(1000000000, 9999999999))  # unique account number

        query = """
        INSERT INTO accounts (customer_id, account_number, account_type, balance)
        VALUES (%s, %s, %s, %s)
        """
        values = (customer_id, account_number, account_type, initial_deposit)
        cursor.execute(query, values)
        conn.commit()
        print(f"✅ Account created successfully! Account Number: {account_number}")

    except Exception as e:
        print("❌ Error creating account:", e)
    finally:
        conn.close()
