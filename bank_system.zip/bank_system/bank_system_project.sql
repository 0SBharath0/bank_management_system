create database bank_system;
use bank_system;

CREATE TABLE customers (
    customer_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE,
    phone VARCHAR(15),
    dob DATE
);
-- acounts table linked with customers table
CREATE TABLE accounts (
    account_id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT,
    account_type ENUM('savings', 'current') NOT NULL,
    balance DECIMAL(12,2) DEFAULT 0.00,
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
);
-- transactions table linked with accounts table
CREATE TABLE transactions (
    txn_id INT AUTO_INCREMENT PRIMARY KEY,
    account_id INT,
    txn_type ENUM('deposit', 'withdraw', 'transfer') NOT NULL,
    amount DECIMAL(12,2) NOT NULL,
    txn_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (account_id) REFERENCES accounts(account_id)
);
select * from accounts;
select * from transactions where account_id=6;
ALTER TABLE accounts 
ADD COLUMN account_number VARCHAR(20) UNIQUE AFTER customer_id;

alter table customers
add constraint unique_phone unique (phone);

select * from accounts;
select * from customers;

ALTER TABLE accounts 
ADD COLUMN is_active TINYINT(1) DEFAULT 1;


ALTER TABLE accounts ADD COLUMN status ENUM('active','closed') DEFAULT 'active';

ALTER TABLE transactions 
MODIFY COLUMN txn_type 
ENUM('deposit', 'withdraw', 'transfer_in', 'transfer_out', 'account_closure') NOT NULL;


SELECT DISTINCT txn_type FROM transactions;


